from django.apps import AppConfig


class TheAppConfig(AppConfig):
    name = 'the_app'
